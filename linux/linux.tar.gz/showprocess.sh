ps aux | grep $1
