echo "Use dot . the decimal numbers"
echo "Insert your weight(KG)"
read weight
echo "Insert your height(M) "
read height

python -c "print($weight/($height*$height))"
