echo "Insert frist number"
read x
echo "Insert second number"
read y
(( sum =x+y ))
echo "The result of $x + $y= $sum"
