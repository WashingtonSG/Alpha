getdata()
let data;

async function getdata(){
  const response = await fetch('/users')
  data = await response.json()
  console.log(data)
 
}
async function  filterData() {
  const id = document.getElementById("input-id").value;
  const name = document.getElementById("input-name").value;
  const email = document.getElementById("input-email").value;
  let formResponse = await fetch(`/response?id=${id}&name=${name}&email=${email}`)

  formResponse = await formResponse.json();
  console.log(formResponse)
} 

